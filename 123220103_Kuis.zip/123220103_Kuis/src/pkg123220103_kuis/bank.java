/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg123220103_kuis;

/**
 *
 * @author Lab Informatika
 */
public class bank {
    private double saldo, jumlah, tambah;
    
    public bank (double saldo)
    {
        this.saldo = saldo;
        
    }
    public void updatesaldo(double jumlah, double tambah){
        
        if(tambah == 1)
        {
            this.saldo = this.saldo + jumlah;
        }else 
        {
         if(this.saldo > jumlah)
         {
            this.saldo = this.saldo - jumlah;
         }
        }
    }
    
}
