/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg123220103_kuis;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author Lab Informatika
 */
public class menuLogin extends JFrame implements actionlistener {
    JLabel header = new JLabel ("Bank AI");
    JLabel txtnum = new JLabel ("Masukkan PIN Anda");
    JTextField num = new JTextField();
    JButton login = new Jbutton("login");
   menuLogin ()
{
    setVisible(True);
    setTitle("Login");
    setSize(720,720);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setlayout(null);
    
    add(header);
    header.setBounds(20,80,200,20);
    
    add(txtnum);
    txtnum.setBounds(20,100,200,20);
    
    add(num);
    num.setBounds(250,80,300,20);
    
    add(login);
    login.setBounds(200, 170,300,20);
}
}