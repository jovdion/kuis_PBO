package pkg123220103_kuis;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Lab Informatika
 */
public class Login {
    private double pin;
    
    public Login (double pin)
    {
        this.pin = pin;
        
    }
    public double cekpin(){
        if(pin == 123220103)
        {
            return 1;
        }else 
        {
            return 0;
        }
    }
    
    
    
}
